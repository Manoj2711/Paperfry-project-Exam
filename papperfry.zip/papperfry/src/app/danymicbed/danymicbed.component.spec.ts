import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DanymicbedComponent } from './danymicbed.component';

describe('DanymicbedComponent', () => {
  let component: DanymicbedComponent;
  let fixture: ComponentFixture<DanymicbedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DanymicbedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DanymicbedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
