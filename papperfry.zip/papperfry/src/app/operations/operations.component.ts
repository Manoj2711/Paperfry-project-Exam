import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-operations',
  templateUrl: './operations.component.html',
  styleUrls: ['./operations.component.css']
})
export class OperationsComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private fb1: FormBuilder,
  ) { }

  fbGroup = this.fb.group(
    {
      producttype: ['', [Validators.required, Validators.minLength(30)]],
      productname: ['', [Validators.required, Validators.maxLength(30)]],
      qty: ['', [Validators.required]],
      price: ['', [Validators.required]],
      img: ['', [Validators.required]],
    })


  fbGroup1 = this.fb1.group(
    {
      producttype: ['', [Validators.required, Validators.minLength(30)]],
      productname: ['', [Validators.required, Validators.maxLength(30)]],
      qty: ['', [Validators.required]],
      price: ['', [Validators.required]],
    })

  async ngOnInit() {
    const mail = sessionStorage.getItem('Adminemail');
    if (mail == undefined || mail.length < 1 || mail == null) {
      await alert("You are not authenticated user please login to continue");
      this.router.navigate(['admin']);
    }


  }

  async adding() {

    const data = this.fbGroup.value;
    console.log(data);

    const url = 'http://localhost:3000/addproduct';

    const user: any = await this.http.post(url, data).toPromise();

    if (user.status) {
      await alert("You have successfully Added your product");

      this.router.navigate(['operations']);
    }

    else if (user.status === false) {
      alert("Server or Database down")
    }

    else if (user.message) {
      alert(user.message)
    }
  }


  async deleting() {

    const data = this.fbGroup1.value;
    console.log(data);

    const url = 'http://localhost:3000/delproduct';

    const user: any = await this.http.post(url, data).toPromise();

    if (user.status) {
      await alert("You have successfully Deleted your product");

      this.router.navigate(['operations']);
    }

    else if (user.status === false) {
      alert("You can only delele items present in database");
    }

    else if (user.message) {
      alert(user.message)
    }
  }



}
