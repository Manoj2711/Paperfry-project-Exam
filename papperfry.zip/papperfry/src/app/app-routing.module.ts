import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginformComponent } from './loginform/loginform.component';
import { SignupComponent } from './signup/signup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { EmailbarComponent } from './emailbar/emailbar.component';
import { DynamicwpComponent } from './dynamicwp/dynamicwp.component';
import { DanymicbedComponent } from './danymicbed/danymicbed.component';
import { CrudComponent } from './crud/crud.component';
import { OperationsComponent } from './operations/operations.component';
import { ChairComponent } from './chair/chair.component';
import { CabinetryComponent } from './cabinetry/cabinetry.component';


const routes: Routes = [
  { path: 'login', component: LoginformComponent },
  { path: 'signup', component: SignupComponent },
  { path: '', component: HomepageComponent },
  { path: 'home', component: HomepageComponent },
  { path: 'emailbar', component: EmailbarComponent },
  { path: 'sofa', component: DynamicwpComponent },
  { path: 'beds', component: DanymicbedComponent },
  { path: 'admin', component: CrudComponent },
  { path: 'operations', component: OperationsComponent },
  { path: 'chair', component: ChairComponent },
  { path: 'cabinetery', component: CabinetryComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
