import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  public uiInvalidCredential = false;

  fbGroup = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  ngOnInit(): void { }

  async loginProcessHere() {
    const data = this.fbGroup.value;


    const url = 'http://localhost:3000/auth-user';
    const result: any = await this.http.post(url, data).toPromise();
    if (result.message) {
      alert(result.message);
    }



    else if (result[0].email) {
      console.log(result[0].email);
      sessionStorage.setItem('sid', 'true');
      alert("You Have Successfully logged in...!");
      sessionStorage.setItem('Adminemail', result[0].email);
      this.router.navigate(['operations']);
    }

    else {
      if (!result.opr) {
        alert("Server side FAILURE...Please try again later ")
      }
      console.log("Error")
      this.uiInvalidCredential = true;
    }
  }

}
