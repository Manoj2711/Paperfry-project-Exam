import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-loginform',
  templateUrl: './loginform.component.html',
  styleUrls: ['./loginform.component.css']
})
export class LoginformComponent implements OnInit {

  public uiInvalidCredential = false;

  fbGroup = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  ngOnInit(): void { }

  async loginProcessHere() {
    const data = this.fbGroup.value;


    const url = 'http://localhost:3000/auth-user';
    const result: any = await this.http.post(url, data).toPromise();
    if (result.message) {
      alert(result.message);
    }



    else if (result[0].email) {
      console.log(result[0].email);
      sessionStorage.setItem('sid', 'true');
      alert("You Have Successfully logged in...!");
      sessionStorage.setItem('email', result[0].email);
      this.router.navigate(['emailbar']);
    }

    else {
      if (!result.opr) {
        alert("Server side FAILURE...Please try again later ")
      }
      console.log("Error")
      this.uiInvalidCredential = true;
    }
  }


}
