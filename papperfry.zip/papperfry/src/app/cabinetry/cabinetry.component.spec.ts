import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabinetryComponent } from './cabinetry.component';

describe('CabinetryComponent', () => {
  let component: CabinetryComponent;
  let fixture: ComponentFixture<CabinetryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabinetryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabinetryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
