import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-chair',
  templateUrl: './chair.component.html',
  styleUrls: ['./chair.component.css']
})
export class ChairComponent implements OnInit {

  constructor(private router: Router,
    private http: HttpClient
  ) { }

  heroes = [];

  arr1 = [];
  arr2 = [];

  async ngOnInit() {

    const mail = sessionStorage.getItem('email');
    if (mail == undefined || mail.length < 1 || mail == null) {
      alert("You are not authenticated user please login to continue");
      this.router.navigate(['']);
    }
    // To display log in
    //  const mail = sessionStorage.getItem("email")
    this.heroes.push(mail);
    // TO feth data sofa in database
    const data = { producttype: "chair" };
    const url = 'http://localhost:3000/dynamic';
    const result: any = await this.http.post(url, data).toPromise();
    console.log(result);
    this.arr1 = result;
    console.log(this.arr1);

  }

  logoutprocess() {
    sessionStorage.removeItem("email");
    alert("You have successfully logged out...!")
    this.router.navigate(['']);
  }





  getdata(obj) {

  }


}
