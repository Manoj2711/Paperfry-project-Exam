import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  fbGroup = this.fb.group(
    {
      username: ['', [Validators.required, Validators.minLength(30)]],
      password: ['', [Validators.required, Validators.maxLength(30)]],
      email: ['', [Validators.required]],
      mobile: ['', [Validators.required]],
    }
  )


  ngOnInit(): void {
  }

  async registerprocess() {

    const data = this.fbGroup.value;
    const url = 'http://localhost:3000/adduser';

    const user: any = await this.http.post(url, data).toPromise();
    if (user.status) {
      alert("You have successfully created your account");

      this.router.navigate(['login']);
    }

    else if (user.status === false) {
      alert("Server or Database down")
    }

    else if (user.message) {
      alert(user.message)
    }

  }

}
