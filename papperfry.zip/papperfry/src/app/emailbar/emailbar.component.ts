import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emailbar',
  templateUrl: './emailbar.component.html',
  styleUrls: ['./emailbar.component.css']
})
export class EmailbarComponent implements OnInit {

  constructor(private router: Router) { }

  heroes = [];

  ngOnInit(): void {

    const mail = sessionStorage.getItem('email');
    if (mail == undefined || mail.length < 1 || mail == null) {
      alert("You are not authenticated user please login to continue");
      this.router.navigate(['']);
    }
    // const mail = sessionStorage.getItem("email")
    this.heroes.push(mail);
  }

  logoutprocess() {
    sessionStorage.removeItem("email");
    sessionStorage.removeItem("Adminemail");
    alert("You have successfully logged out...!")
    this.router.navigate(['']);
  }


}
