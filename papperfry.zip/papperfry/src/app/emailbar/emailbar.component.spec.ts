import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailbarComponent } from './emailbar.component';

describe('EmailbarComponent', () => {
  let component: EmailbarComponent;
  let fixture: ComponentFixture<EmailbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
