import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginformComponent } from './loginform/loginform.component';
import { SignupComponent } from './signup/signup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { EmailbarComponent } from './emailbar/emailbar.component';
import { DynamicwpComponent } from './dynamicwp/dynamicwp.component';
import { DanymicbedComponent } from './danymicbed/danymicbed.component';
import { CrudComponent } from './crud/crud.component';
import { OperationsComponent } from './operations/operations.component';
import { ChairComponent } from './chair/chair.component';
import { CabinetryComponent } from './cabinetry/cabinetry.component';
//import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [
    AppComponent,
    LoginformComponent,
    SignupComponent,
    HomepageComponent,
    EmailbarComponent,
    DynamicwpComponent,
    DanymicbedComponent,
    CrudComponent,
    OperationsComponent,
    ChairComponent,
    CabinetryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    //NgbDropdown
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
