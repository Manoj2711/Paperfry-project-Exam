const express = require("express");
const cors = require("cors");
const multer = require("multer");

const app = express();

// Middelware :: Programs :: Which runs in advance.
app.use(cors()); // unblocking cors policy
app.use(express.json()); // BODY :: RAW :: JSON
app.use(express.urlencoded({ extended: true })); // BODY :: URL ENCODED
const upload = multer(); // BODY :: FORM DATA

const dbadduser = require("./db.add.user");

// http://localhost:3000/welcome
app.get("/a", (req, res) => {
  res.json({ title: "Welcome!!" });
});

// created an API
// learnt how to read the input; coming from client.
// http://localhost:3000/adduser?username=hello
app.get("/adduser", async (req, res) => {
  try {
    // lets read the query parameter
    const input = req.query;

    // calling db logic :: async :: non blocking
    await dbadduser.addUser(input);
    res.json({ message: "success" });
  } catch (err) {
    res.json({ message: "failure" });
  }
});

// POST API :: FOR TESTIG POSTMAN :: ANDROID :: IOS :: BROWSER
// http://localhost:3000/adduser
app.post("/adduser", async (req, res) => {
  try {
    const input = req.body; // before doing this

    if (input.username == null || input.password == null || input.email == null || input.mobile == null) {
      res.json({ message: "Fields cannot be empty" })
    }

    else if (Number(input.mobile) == NaN) {
      res.json({ message: "Mobile must be in numbers" })
    }

    else if (input.mobile.length != 10) {
      res.json({ message: "Mobile number must have 10 digits OR Enter without country code" })
    }

    else if (input.email.search("@") === -1 || input.email.search("@") === 0) {
      res.json({ message: "Email field is not valid please enter in this form : example@example.com" })
    }

    else {
      // Adding user in Database
      await dbadduser.addUser(input);
      res.json({ status: true });
    }

  } catch (err) {
    console.log(err);
    res.json({ status: false });
  }
});

app.post("/auth-user", async (req, res) => {
  try {
    const input = req.body;

    if (input.username == null) {
      res.json({ message: "Username Field cannot be empty" })
    }

    else if (input.password == null) {
      res.json({ message: "Password Field cannot be empty" })
    }

    else {
      const result = await dbadduser.authenticateUser(input);
      //  result.opr = true;
      if (result.length != 0) {

        console.log(result);
        res.json(result);
        // res.json({ opr: true });
      }
      else {
        res.json({ message: "Wrong Username OR Password" })
      }

    }

  } catch (err) {
    res.json({ opr: false });
  }
});

app.post("/dynamic", async (req, res) => {
  try {

    const input = req.body;
    console.log(input);

    const result = await dbadduser.dynamicdata(input.producttype);
    //  result.opr = true;
    if (result.length != 0) {

      console.log(result);
      res.json(result);
      // res.json({ opr: true });
    }
  } catch (err) {
    console.log(err);
    res.send(err);
  }

});


app.post("/addproduct", async (req, res) => {
  try {
    const input = req.body; // before doing this
    console.log(input);

    if (input.producttype == null || input.productname == null || input.qty == null || input.price == null || input.img == null) {
      res.json({ message: "Fields cannot be empty" })
    }

    else {
      // Adding user in Database
      await dbadduser.addproduct(input);
      res.json({ status: true });
    }

  } catch (err) {
    console.log(err);
    res.json({ status: false });
  }
});

app.post("/delproduct", async (req, res) => {
  try {
    const input = req.body; // before doing this
    console.log(input);

    if (input.producttype == null || input.productname == null || input.qty == null || input.price == null) {
      res.json({ message: "Fields cannot be empty" })
    }

    else {
      // deleting user in Database
      const result = await dbadduser.delproduct(input);
      res.json(result);
    }

  } catch (err) {
    console.log(err);
    res.json({ status: false });
  }
});



app.post("/sample", upload.none(), async (req, res) => {
  res.json(req.body);
});

// started teh server.
app.listen(3000);
