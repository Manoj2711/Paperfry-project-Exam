const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
  host: "localhost",
  user: "root",
  password: "cdac",
  database: "mean_stu",
};

let addUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "INSERT INTO USER1 (USERNAME, PASSWORD, EMAIL, MOBILE) VALUES (?, ?, ?, ?)";
  await connection.queryAsync(sql, [
    input.username,
    input.password,
    input.email,
    input.mobile,
  ]);

  await connection.endAsync();
};

let authenticateUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM USER1 WHERE USERNAME=? AND PASSWORD=?";
  const results = await connection.queryAsync(sql, [
    input.username,
    input.password,
  ]);

  await connection.endAsync();

  // if (results.length === 0) {
  //   throw new Error("Invalid Credentials");
  // }

  return results;
};


let dynamicdata = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM  PRODUCT WHERE PRODUCTTYPE=?";
  const results = await connection.queryAsync(sql, [
    input
  ]);

  await connection.endAsync();

  // if (results.length === 0) {
  //   throw new Error("Invalid Credentials");
  // }
  console.log(results);
  return results;
};

let addproduct = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "INSERT INTO  PRODUCT VALUES (?, ?, ?, ?,?)";
  await connection.queryAsync(sql, [
    input.productname,
    input.producttype,
    input.price,
    input.qty,
    input.img,
  ]);

  await connection.endAsync();
};

let delproduct = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM  PRODUCT WHERE PRODUCTTYPE=? AND PRODUCTNAME=?";
  const results = await connection.queryAsync(sql, [
    input.producttype,
    input.productname,
  ]);

  var success = { status: false }

  if (results.length > 0) {

    let sql = "DELETE FROM  PRODUCT WHERE PRODUCTNAME=? AND PRODUCTTYPE=?";
    await connection.queryAsync(sql, [
      input.productname,
      input.producttype,
    ]);

    success.status = true;
  }


  await connection.endAsync();

  return success;
};



//dynamicdata('sofa');
module.exports = { addUser, authenticateUser, dynamicdata, addproduct, delproduct };
